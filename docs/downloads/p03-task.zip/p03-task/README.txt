eCDFP Diploma - P03 - the task (handed in before P04)
=====================================================
Five files with no extension: file02 file05 file09 file13 file14

For EACH file:
  1. the first 16 bytes (HxD, or: Format-Hex -Path .\file02 -Count 16)
  2. the signature you matched, and where you looked it up
  3. the real format, and the extension it should carry
  4. one finding line (F-xx) written in the fixed format

For file02 there is one more question:
  5. the file carries EXIF. In which CITY was the photograph taken?
     Name the two EXIF fields you used, and how you resolved them to a place.

Verify first:
  PS> Get-FileHash * -Algorithm SHA256      (compare with SHA256SUMS.txt)

Then the report: Section 6 gets one row per tool WITH its version;
Section 8 gets your five findings. Do not write the answers here - write them in the report.

These are teaching files, not evidence from any real case.
