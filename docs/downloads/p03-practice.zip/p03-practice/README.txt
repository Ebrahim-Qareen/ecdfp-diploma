eCDFP Diploma - P03 - practice set (instructor demo)
=====================================================
Four files. Open each one in HxD (File > Open) and read the FIRST bytes.
Compare what the bytes say with what the name says.

  File09       - no extension at all
  File10.png
  File11.docx
  File12.mp4

Verify before you open anything:
  PS> Get-FileHash * -Algorithm SHA256
  compare with SHA256SUMS.txt

These are teaching files, not evidence from any real case.
