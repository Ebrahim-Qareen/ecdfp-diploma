eCDFP Diploma - P01 - the task (handed in before P02)
=====================================================
1. On FOR-WS01, from your build-scripts folder:   .\verify_tools.ps1   -> must end "Missing: 0"
2. Pick ANY TWO tools in C:\Forensics\Tools. For each: Get-FileHash -Algorithm SHA256,
   its line in TOOLS.sha256, both digests, and the RESULT (match / mismatch).
3. Each tool's VERSION - from the binary's properties or --version, never the folder name.
4. Open report.md (this is your report for the whole course). Complete Section 1, Section 3, Section 6.
5. From artifact.txt write F-01, I-01 and one "cannot prove" line, in the fixed formats.

Graded on the four criteria in report.md. A perfect F-01 with a decorative cannot-prove line
loses criterion 4.
